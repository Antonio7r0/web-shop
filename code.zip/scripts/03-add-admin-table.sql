-- Tabla para administradores
CREATE TABLE IF NOT EXISTS admin_users (
  id BIGINT PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
  username VARCHAR(255) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT NOW()
);

-- Insertar usuario admin por defecto
-- Usuario: Dv23, Contraseña: administrador (en producción usar hash)
INSERT INTO admin_users (username, password) VALUES ('Dv23', 'administrador');

-- Crear tabla para registrar cambios de stock
CREATE TABLE IF NOT EXISTS stock_history (
  id BIGINT PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
  product_id BIGINT REFERENCES products(id) ON DELETE CASCADE,
  quantity_changed INT NOT NULL,
  reason VARCHAR(255), -- 'venta', 'ajuste_manual', 'devolucion'
  created_at TIMESTAMP DEFAULT NOW()
);

-- Crear índices
CREATE INDEX idx_stock_history_product ON stock_history(product_id);
