-- Actualizado con URLs de imágenes reales y más variedad de productos

-- ALMOHADAS
INSERT INTO products (name, description, price, category, image_url, stock) VALUES
('Almohada Goku SSJ', 'Almohada suave con el rostro de Goku en forma Super Saiyan', 45.99, 'almohadas', 'https://via.placeholder.com/300?text=Almohada+Goku', 12),
('Almohada Naruto Uzumaki', 'Almohada cuadrada cómoda con patrón de Naruto', 42.50, 'almohadas', 'https://via.placeholder.com/300?text=Almohada+Naruto', 8),
('Almohada Pikachu', 'Almohada amarilla suave en forma de Pikachu', 48.00, 'almohadas', 'https://via.placeholder.com/300?text=Almohada+Pikachu', 15),
('Almohada Asuna (SAO)', 'Almohada decorativa con la protagonista de Sword Art Online', 50.00, 'almohadas', 'https://via.placeholder.com/300?text=Almohada+Asuna', 6),
('Almohada Rem (Re:Zero)', 'Almohada de Rem con cabello azul - muy acogedora', 52.00, 'almohadas', 'https://via.placeholder.com/300?text=Almohada+Rem', 10);

-- ROPA
INSERT INTO products (name, description, price, category, image_url, stock) VALUES
('Polo Dragon Ball', 'Polo premium 100% algodón con diseño exclusivo de Dragon Ball', 39.99, 'ropa', 'https://via.placeholder.com/300?text=Polo+Dragon+Ball', 20),
('Polo One Piece Luffy', 'Polo cómodo y duradero con el logo de One Piece', 39.99, 'ropa', 'https://via.placeholder.com/300?text=Polo+One+Piece', 18),
('Casaca Attack on Titan', 'Casaca negra premium de Shingeki no Kyojin', 89.99, 'ropa', 'https://via.placeholder.com/300?text=Casaca+AOT', 5),
('Casaca Jujutsu Kaisen', 'Casaca versátil y elegante con diseño Jujutsu Kaisen', 85.00, 'ropa', 'https://via.placeholder.com/300?text=Casaca+Jujutsu', 7),
('Hoodie My Hero Academia', 'Hoodie cómodo con logo de Academia de Héroes', 74.99, 'ropa', 'https://via.placeholder.com/300?text=Hoodie+MHA', 10),
('Polo Death Note', 'Polo blanco elegante con manzana de Death Note', 40.00, 'ropa', 'https://via.placeholder.com/300?text=Polo+Death+Note', 14),
('Casaca Demon Slayer', 'Casaca gruesa de Kimetsu no Yaiba', 92.00, 'ropa', 'https://via.placeholder.com/300?text=Casaca+Demon+Slayer', 6);

-- FIGURITAS
INSERT INTO products (name, description, price, category, image_url, stock) VALUES
('Figura Goku Ultra Instinct', 'Figura articulada detallada de Goku en Ultra Instinct - 20cm', 65.00, 'figuritas', 'https://via.placeholder.com/300?text=Figura+Goku+UI', 8),
('Figura Vegeta SSJ Blue', 'Figura premium de Vegeta en forma SSJ Blue - 19cm', 68.00, 'figuritas', 'https://via.placeholder.com/300?text=Figura+Vegeta', 6),
('Figura Naruto Hokage', 'Figura de Naruto en su forma como Hokage - 18cm', 55.00, 'figuritas', 'https://via.placeholder.com/300?text=Figura+Naruto', 10),
('Figura Luffy King of Pirates', 'Figura de Luffy con sus armas - 16cm', 70.00, 'figuritas', 'https://via.placeholder.com/300?text=Figura+Luffy', 7),
('Figura Tanjiro Kamado', 'Figura articulada de Tanjiro en forma de Hashira - 17cm', 62.00, 'figuritas', 'https://via.placeholder.com/300?text=Figura+Tanjiro', 9),
('Figura All Might', 'Figura imponente del héroe supremo - 25cm', 75.00, 'figuritas', 'https://via.placeholder.com/300?text=Figura+All+Might', 5),
('Figura Rem', 'Figura detallada de Rem en pose sentada - 10cm', 58.00, 'figuritas', 'https://via.placeholder.com/300?text=Figura+Rem', 12),
('Figura Saitama', 'Figura del hombre más fuerte - 15cm', 60.00, 'figuritas', 'https://via.placeholder.com/300?text=Figura+Saitama', 8),
('Figura Itachi Uchiha', 'Figura coleccionable de Itachi con sus armas - 18cm', 72.00, 'figuritas', 'https://via.placeholder.com/300?text=Figura+Itachi', 4);
