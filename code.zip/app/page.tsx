"use client"

import { useState, useEffect, useRef } from "react"
import Header from "@/components/header"
import Navigation from "@/components/navigation"
import ProductCategorySection from "@/components/product-category-section"
import CartSidebar from "@/components/cart-sidebar"
import SettingsSidebar from "@/components/settings-sidebar"
import { supabase } from "@/lib/supabase"

export default function Home() {
  const [cartItems, setCartItems] = useState<any[]>([])
  const [showSettings, setShowSettings] = useState(false)
  const [products, setProducts] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [activeCategory, setActiveCategory] = useState("almohadas")
  const [isMobile, setIsMobile] = useState(false)

  const categoryRefs = useRef<Record<string, HTMLDivElement | null>>({})

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 1024)
    }

    handleResize()
    window.addEventListener("resize", handleResize)
    return () => window.removeEventListener("resize", handleResize)
  }, [])

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const { data, error } = await supabase.from("products").select("*").order("category").order("name")

        if (error) throw error
        setProducts(data || [])
      } catch (error) {
        console.error("Error fetching products:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchProducts()

    const subscription = supabase
      .channel("products-changes")
      .on("postgres_changes", { event: "*", schema: "public", table: "products" }, (payload: any) => {
        setProducts((prevProducts) => {
          if (payload.eventType === "DELETE") {
            return prevProducts.filter((p) => p.id !== payload.old.id)
          } else if (payload.eventType === "INSERT") {
            return [...prevProducts, payload.new]
          } else if (payload.eventType === "UPDATE") {
            return prevProducts.map((p) => (p.id === payload.new.id ? payload.new : p))
          }
          return prevProducts
        })
      })
      .subscribe()

    return () => {
      subscription.unsubscribe()
    }
  }, [])

  const addToCart = (product: any) => {
    if (product.stock <= 0) {
      alert("Este producto está agotado")
      return
    }

    setCartItems((prevItems) => {
      const existingItem = prevItems.find((item) => item.id === product.id)
      if (existingItem) {
        if (existingItem.quantity >= product.stock) {
          alert(`Solo hay ${product.stock} disponibles`)
          return prevItems
        }
        return prevItems.map((item) => (item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item))
      }
      return [...prevItems, { ...product, quantity: 1 }]
    })
  }

  const removeFromCart = (productId: number) => {
    setCartItems((prevItems) => prevItems.filter((item) => item.id !== productId))
  }

  const handleCategorySelect = (category: string) => {
    setActiveCategory(category)
    categoryRefs.current[category]?.scrollIntoView({ behavior: "smooth" })
  }

  const categories = ["almohadas", "ropa", "figuritas"]
  const categoryLabels: Record<string, string> = {
    almohadas: "Almohadas",
    ropa: "Ropa",
    figuritas: "Figuritas",
  }

  return (
    <main className="min-h-screen bg-gradient-to-b from-purple-50 to-pink-50">
      <Header />
      <Navigation
        activeCategory={activeCategory}
        onSettingsClick={() => setShowSettings(!showSettings)}
        onCategorySelect={handleCategorySelect}
      />

      <div className="flex flex-col lg:flex-row gap-4 lg:gap-6 p-4 md:p-6 lg:p-8 max-w-7xl mx-auto">
        {/* Main Content */}
        <div className="flex-1 w-full">
          {loading ? (
            <div className="text-center py-12">
              <p className="text-gray-600 text-lg">Cargando productos...</p>
            </div>
          ) : (
            <div className="space-y-8 md:space-y-12">
              {categories.map((category) => (
                <div
                  key={category}
                  ref={(el) => {
                    if (el) categoryRefs.current[category] = el
                  }}
                >
                  <ProductCategorySection
                    category={category}
                    categoryLabel={categoryLabels[category]}
                    products={products.filter((p) => p.category === category)}
                    onAddToCart={addToCart}
                  />
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Sidebars - Responsive positioning */}
        <div
          className={`w-full ${isMobile ? "fixed bottom-0 left-0 right-0 z-40" : "lg:w-80"} space-y-6 flex flex-col`}
        >
          <CartSidebar items={cartItems} onRemove={removeFromCart} />
          {showSettings && <SettingsSidebar />}
        </div>
      </div>
    </main>
  )
}
