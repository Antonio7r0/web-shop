import { createServerClient } from "@supabase/ssr"
import { cookies } from "next/headers"

export async function PUT(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const cookieStore = cookies()
  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() {
          return cookieStore.getAll()
        },
      },
    },
  )

  const { stock } = await request.json()

  const { data, error } = await supabase.from("products").update({ stock }).eq("id", id).select()

  if (error) {
    return Response.json({ error: error.message }, { status: 500 })
  }

  const oldProduct = await supabase.from("products").select("stock").eq("id", id).single()

  return Response.json(data[0])
}
