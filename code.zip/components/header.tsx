"use client"

import { useState } from "react"

export default function Header() {
  const [searchQuery, setSearchQuery] = useState("")

  return (
    <header className="bg-gradient-to-r from-purple-600 to-pink-600 text-white py-8 px-4">
      <div className="max-w-7xl mx-auto">
        {/* 
          LOGO AQUÍ: Happy People Store
          - Tamaño recomendado: 200x200px o 300x100px
          - Formato: PNG con transparencia
          - Posición: Reemplazar o colocar junto al texto
          - Sustituyendo el texto "HAPPY PEOPLE STORE" por la imagen del logo
        */}
        <h1 className="text-4xl lg:text-5xl font-bold mb-2 text-center">HAPPY PEOPLE STORE</h1>
        <p className="text-purple-100 text-center mb-6">Tu tienda de artículos anime en Arequipa</p>

        <div className="flex justify-center">
          <input
            type="text"
            placeholder="Store Center - Busca tus productos anime favoritos..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full lg:w-2/3 px-4 py-3 rounded-lg text-gray-800 focus:outline-none focus:ring-2 focus:ring-purple-300 text-base"
          />
        </div>
      </div>
    </header>
  )
}
