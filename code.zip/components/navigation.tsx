"use client"

interface NavigationProps {
  onSettingsClick: () => void
  activeCategory: string
  onCategorySelect: (category: string) => void
}

export default function Navigation({ onSettingsClick, activeCategory, onCategorySelect }: NavigationProps) {
  return (
    <nav className="bg-white shadow-md sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
        <div className="flex gap-6">
          <button
            onClick={() => onCategorySelect("almohadas")}
            className={`font-semibold transition-colors ${
              activeCategory === "almohadas"
                ? "text-purple-600 border-b-2 border-purple-600"
                : "text-gray-600 hover:text-purple-600"
            }`}
          >
            Almohadas
          </button>
          <button
            onClick={() => onCategorySelect("ropa")}
            className={`font-semibold transition-colors ${
              activeCategory === "ropa"
                ? "text-purple-600 border-b-2 border-purple-600"
                : "text-gray-600 hover:text-purple-600"
            }`}
          >
            Ropa
          </button>
          <button
            onClick={() => onCategorySelect("figuritas")}
            className={`font-semibold transition-colors ${
              activeCategory === "figuritas"
                ? "text-purple-600 border-b-2 border-purple-600"
                : "text-gray-600 hover:text-purple-600"
            }`}
          >
            Figuritas
          </button>
        </div>
        <button
          onClick={onSettingsClick}
          className="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition-colors font-semibold"
        >
          Ajustes
        </button>
      </div>
    </nav>
  )
}
