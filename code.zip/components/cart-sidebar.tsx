"use client"

import { useState } from "react"
import CheckoutModal from "./checkout-modal"

interface CartItem {
  id: number
  name: string
  price: number
  quantity: number
  image_url?: string
}

interface CartSidebarProps {
  items: CartItem[]
  onRemove: (productId: number) => void
}

export default function CartSidebar({ items, onRemove }: CartSidebarProps) {
  const [showCheckout, setShowCheckout] = useState(false)

  const total = items.reduce((sum, item) => sum + item.price * item.quantity, 0)
  const itemCount = items.reduce((sum, item) => sum + item.quantity, 0)

  return (
    <>
      <div className="bg-white rounded-xl shadow-lg p-4 md:p-6 sticky top-24 lg:top-24 max-h-96 lg:max-h-full overflow-auto">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl md:text-2xl font-bold text-purple-600">🛒 Carrito</h3>
          {items.length > 0 && (
            <span className="bg-pink-600 text-white text-xs font-bold px-2 md:px-3 py-1 rounded-full">{itemCount}</span>
          )}
        </div>

        {items.length === 0 ? (
          <p className="text-gray-500 text-center py-8 text-sm md:text-base">Tu carrito está vacío</p>
        ) : (
          <>
            <div className="space-y-2 md:space-y-3 max-h-48 md:max-h-64 overflow-y-auto mb-4">
              {items.map((item) => (
                <div
                  key={item.id}
                  className="bg-gray-50 p-2 md:p-3 rounded-lg flex justify-between items-start hover:bg-gray-100 transition-colors"
                >
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-gray-800 text-sm line-clamp-1">{item.name}</p>
                    <p className="text-xs text-gray-600 mt-1">
                      {item.quantity}x S/. {Number(item.price).toFixed(2)}
                    </p>
                    <p className="text-xs font-semibold text-pink-600 mt-1">
                      S/. {(item.quantity * item.price).toFixed(2)}
                    </p>
                  </div>
                  <button
                    onClick={() => onRemove(item.id)}
                    className="text-red-600 hover:text-red-800 hover:bg-red-100 ml-2 p-1 rounded transition-colors flex-shrink-0"
                    title="Eliminar del carrito"
                  >
                    ✕
                  </button>
                </div>
              ))}
            </div>

            <div className="border-t-2 border-purple-200 pt-3 md:pt-4 mb-3 md:mb-4">
              <div className="flex justify-between items-center mb-3 md:mb-4">
                <span className="font-bold text-gray-800 text-sm md:text-base">Total:</span>
                <span className="text-xl md:text-2xl font-bold text-pink-600">S/. {total.toFixed(2)}</span>
              </div>

              <button
                onClick={() => setShowCheckout(true)}
                className="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white py-2.5 md:py-3 rounded-lg font-bold hover:from-purple-700 hover:to-pink-700 transition-all duration-200 active:scale-95 text-sm md:text-base"
              >
                💳 Proceder al Pago
              </button>
            </div>
          </>
        )}
      </div>

      <CheckoutModal items={items} total={total} onClose={() => setShowCheckout(false)} isOpen={showCheckout} />
    </>
  )
}
