import ProductCard from "./product-card"

interface ProductCategorySectionProps {
  category: string
  categoryLabel: string
  products: any[]
  onAddToCart: (product: any) => void
}

export default function ProductCategorySection({
  category,
  categoryLabel,
  products,
  onAddToCart,
}: ProductCategorySectionProps) {
  return (
    <section className="bg-white rounded-xl p-6 shadow-lg">
      <h2 className="text-3xl font-bold text-purple-600 mb-6">{categoryLabel}</h2>

      {products.length === 0 ? (
        <div className="text-center py-8 text-gray-500">
          <p>No hay productos disponibles en esta categoría</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {products.map((product) => (
            <ProductCard key={product.id} product={product} onAddToCart={onAddToCart} />
          ))}
        </div>
      )}
    </section>
  )
}
