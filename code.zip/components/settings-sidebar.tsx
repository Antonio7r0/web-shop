"use client"

import { useState } from "react"
import Link from "next/link"

export default function SettingsSidebar() {
  const [activeTab, setActiveTab] = useState("location")
  const [devPassword, setDevPassword] = useState("")
  const [devAuth, setDevAuth] = useState(false)
  const [showDevInput, setShowDevInput] = useState(false)

  const handleDevAccess = () => {
    if (devPassword === "administrador") {
      setDevAuth(true)
      setDevPassword("")
      setShowDevInput(false)
    } else {
      alert("Contraseña incorrecta")
      setDevPassword("")
    }
  }

  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <h3 className="text-2xl font-bold text-purple-600 mb-4">Ajustes</h3>

      <div className="space-y-4">
        {/* Tab Location */}
        <button
          onClick={() => setActiveTab("location")}
          className={`w-full text-left px-4 py-3 rounded-lg font-semibold transition-colors ${
            activeTab === "location" ? "bg-purple-600 text-white" : "bg-gray-100 text-gray-800 hover:bg-gray-200"
          }`}
        >
          📍 Ubicación
        </button>

        {activeTab === "location" && (
          <div className="bg-gray-50 p-4 rounded-lg space-y-3">
            <div>
              <p className="font-semibold text-gray-800 mb-2">Happy People Store</p>
              <p className="text-sm text-gray-700 leading-relaxed">
                Arequipa - Cercado
                <br />
                Calle Santos Domingos 205 Int 108
                <br />
                Galería Los Cristales
              </p>
            </div>

            <div className="mt-4">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3822.8089878293906!2d-71.5390!3d-16.3988!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x915cceae43dd5551%3A0x123!2sGaler%C3%ADa%20Los%20Cristales%2C%20Calle%20Santos%20Domingos%20205%2C%20Arequipa!5e0!3m2!1ses!2spe!4v1700000000000"
                width="100%"
                height="300"
                style={{ border: 0, borderRadius: "8px" }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>

            <div className="space-y-2 mt-4 border-t border-gray-200 pt-4">
              <p className="text-sm text-gray-700">
                <strong>WhatsApp:</strong> +51 952 128 890
              </p>
              <p className="text-sm text-gray-700">
                <strong>Horarios:</strong> Lunes - Sábado: 10:00 AM - 8:00 PM
              </p>
              <p className="text-sm text-gray-700">
                <strong>Horarios:</strong> Domingo: 11:00 AM - 6:00 PM
              </p>
            </div>
          </div>
        )}

        {/* Tab Contacto */}
        <button
          onClick={() => setActiveTab("contact")}
          className={`w-full text-left px-4 py-3 rounded-lg font-semibold transition-colors ${
            activeTab === "contact" ? "bg-purple-600 text-white" : "bg-gray-100 text-gray-800 hover:bg-gray-200"
          }`}
        >
          💬 Contacto Directo
        </button>

        {activeTab === "contact" && (
          <div className="bg-gray-50 p-4 rounded-lg space-y-3">
            <a
              href="https://wa.me/51952128890?text=Hola%20Happy%20People%20Store%20quisiera%20informacion"
              target="_blank"
              rel="noopener noreferrer"
              className="block w-full bg-green-500 text-white py-3 rounded-lg text-center font-semibold hover:bg-green-600 transition-colors"
            >
              WhatsApp
            </a>
            <a
              href="https://www.google.com/maps/place/Galer%C3%ADa+Los+Cristales,+Calle+Santos+Domingos+205,+Arequipa/@-16.3988,-71.5390,15z"
              target="_blank"
              rel="noopener noreferrer"
              className="block w-full bg-blue-500 text-white py-3 rounded-lg text-center font-semibold hover:bg-blue-600 transition-colors"
            >
              Ir a Ubicación
            </a>
          </div>
        )}

        <button
          onClick={() => {
            setActiveTab("dev")
            setShowDevInput(!showDevInput)
          }}
          className={`w-full text-left px-4 py-3 rounded-lg font-semibold transition-colors ${
            activeTab === "dev" ? "bg-purple-600 text-white" : "bg-gray-100 text-gray-800 hover:bg-gray-200"
          }`}
        >
          🔧 DEV
        </button>

        {activeTab === "dev" && (
          <div className="bg-gray-50 p-4 rounded-lg space-y-3">
            {!devAuth ? (
              <>
                {showDevInput ? (
                  <div className="space-y-3">
                    <p className="text-sm text-gray-700">
                      Ingresa la contraseña para acceder al panel de administrador
                    </p>
                    <input
                      type="password"
                      placeholder="Contraseña"
                      value={devPassword}
                      onChange={(e) => setDevPassword(e.target.value)}
                      onKeyPress={(e) => e.key === "Enter" && handleDevAccess()}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                      autoFocus
                    />
                    <button
                      onClick={handleDevAccess}
                      className="w-full bg-purple-600 text-white py-2 rounded-lg font-semibold hover:bg-purple-700 transition-colors"
                    >
                      Acceder
                    </button>
                    <button
                      onClick={() => setShowDevInput(false)}
                      className="w-full bg-gray-300 text-gray-800 py-2 rounded-lg font-semibold hover:bg-gray-400 transition-colors"
                    >
                      Cancelar
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => setShowDevInput(true)}
                    className="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors"
                  >
                    Acceso Administrador
                  </button>
                )}
              </>
            ) : (
              <div className="space-y-3">
                <p className="text-sm text-green-700 font-semibold">✓ Autenticación exitosa</p>
                <Link
                  href="/admin"
                  className="block w-full bg-purple-600 text-white py-3 rounded-lg text-center font-semibold hover:bg-purple-700 transition-colors"
                >
                  Ir a Panel Admin
                </Link>
                <button
                  onClick={() => {
                    setDevAuth(false)
                    setActiveTab("location")
                  }}
                  className="w-full bg-gray-300 text-gray-800 py-2 rounded-lg font-semibold hover:bg-gray-400 transition-colors"
                >
                  Cerrar Sesión
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
