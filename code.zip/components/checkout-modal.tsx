"use client"

import { useState } from "react"
import { supabase } from "@/lib/supabase"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"

interface CartItem {
  id: number
  name: string
  price: number
  quantity: number
  image_url?: string
}

interface CheckoutModalProps {
  items: CartItem[]
  total: number
  onClose: () => void
  isOpen: boolean
}

export default function CheckoutModal({ items, total, onClose, isOpen }: CheckoutModalProps) {
  const [whatsappNumber, setWhatsappNumber] = useState("952128890")
  const [paymentMethod, setPaymentMethod] = useState("yape")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")

  const handleSubmitOrder = async () => {
    if (!whatsappNumber.trim()) {
      setError("Por favor ingresa tu número de WhatsApp")
      return
    }

    setLoading(true)
    setError("")

    try {
      const itemsSummary = items
        .map((item) => `• ${item.quantity}x ${item.name} - S/. ${(item.price * item.quantity).toFixed(2)}`)
        .join("\n")

      const orderMessage = `
*🎌 NUEVO PEDIDO - HAPPY PEOPLE STORE 🎌*
━━━━━━━━━━━━━━━━━━━━━━━

*📦 PRODUCTOS ORDENADOS:*
${itemsSummary}

━━━━━━━━━━━━━━━━━━━━━━━
*💰 TOTAL: S/. ${total.toFixed(2)}*
*💳 MÉTODO DE PAGO: ${paymentMethod === "yape" ? "YAPE 📱" : "TRANSFERENCIA BANCARIA 🏦"}*
━━━━━━━━━━━━━━━━━━━━━━━

✨ ¡Gracias por tu compra en Happy People Store!
Nos pondremos en contacto pronto.
      `.trim()

      // Guardar orden en la base de datos
      const sessionId = `order_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`

      const { error: insertError } = await supabase.from("orders").insert([
        {
          session_id: sessionId,
          total_amount: total,
          payment_method: paymentMethod,
          whatsapp_number: whatsappNumber,
          items_summary: itemsSummary,
          status: "pending",
        },
      ])

      if (insertError) throw insertError

      const storeNumber = "51952128890" // Número de la tienda
      const whatsappUrl = `https://wa.me/${storeNumber}?text=${encodeURIComponent(orderMessage)}`
      window.open(whatsappUrl, "_blank")

      alert("Pedido enviado a WhatsApp. ¡Gracias por tu compra!")
      onClose()
    } catch (err) {
      console.error("Error:", err)
      setError("Error al procesar el pedido. Intenta nuevamente.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="w-full max-w-md">
        <DialogHeader>
          <DialogTitle className="text-2xl text-purple-600">Confirmar Pedido</DialogTitle>
        </DialogHeader>

        {/* Resumen */}
        <div className="bg-gray-50 p-4 rounded-lg max-h-96 overflow-y-auto">
          {items.map((item) => (
            <div
              key={item.id}
              className="flex justify-between text-sm mb-3 pb-3 border-b border-gray-200 last:border-b-0"
            >
              <div className="flex-1">
                <p className="font-semibold text-gray-800">
                  {item.quantity}x {item.name}
                </p>
                <p className="text-xs text-gray-600 mt-1">S/. {Number(item.price).toFixed(2)} c/u</p>
              </div>
              <span className="font-semibold text-pink-600">S/. {(item.price * item.quantity).toFixed(2)}</span>
            </div>
          ))}
          <div className="border-t-2 border-gray-300 pt-3 mt-3 flex justify-between font-bold text-lg">
            <span>Total:</span>
            <span className="text-pink-600">S/. {total.toFixed(2)}</span>
          </div>
        </div>

        {/* WhatsApp */}
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">Tu Número de WhatsApp</label>
            <div className="flex gap-2">
              <span className="flex items-center px-3 bg-gray-100 rounded-lg font-medium text-gray-700">+51</span>
              <input
                type="tel"
                value={whatsappNumber}
                onChange={(e) => setWhatsappNumber(e.target.value.replace(/\D/g, ""))}
                placeholder="952128890"
                className="flex-1 px-4 py-2 border-2 border-purple-200 rounded-lg focus:outline-none focus:border-purple-600"
              />
            </div>
          </div>

          {/* Método de Pago */}
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">Método de Pago</label>
            <div className="space-y-2">
              <label className="flex items-center p-3 border-2 border-purple-200 rounded-lg cursor-pointer hover:bg-purple-50 transition-colors">
                <input
                  type="radio"
                  name="payment"
                  value="yape"
                  checked={paymentMethod === "yape"}
                  onChange={(e) => setPaymentMethod(e.target.value)}
                  className="mr-2 w-4 h-4"
                />
                <span className="font-medium">📱 Yape</span>
              </label>
              <label className="flex items-center p-3 border-2 border-purple-200 rounded-lg cursor-pointer hover:bg-purple-50 transition-colors">
                <input
                  type="radio"
                  name="payment"
                  value="transferencia"
                  checked={paymentMethod === "transferencia"}
                  onChange={(e) => setPaymentMethod(e.target.value)}
                  className="mr-2 w-4 h-4"
                />
                <span className="font-medium">🏦 Transferencia Bancaria</span>
              </label>
            </div>
          </div>

          {error && <div className="bg-red-100 text-red-800 p-3 rounded-lg text-sm">{error}</div>}

          {/* Botones */}
          <div className="flex gap-3 pt-4">
            <button
              onClick={onClose}
              className="flex-1 bg-gray-300 text-gray-800 py-2 rounded-lg font-semibold hover:bg-gray-400 transition-colors"
              disabled={loading}
            >
              Cancelar
            </button>
            <button
              onClick={handleSubmitOrder}
              disabled={loading}
              className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 text-white py-2 rounded-lg font-semibold hover:from-purple-700 hover:to-pink-700 disabled:opacity-50 transition-all"
            >
              {loading ? "Procesando..." : "📱 Enviar por WhatsApp"}
            </button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
