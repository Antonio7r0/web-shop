"use client"

interface ProductCardProps {
  product: any
  onAddToCart: (product: any) => void
}

export default function ProductCard({ product, onAddToCart }: ProductCardProps) {
  const getPlaceholderEmoji = (category: string) => {
    switch (category) {
      case "almohadas":
        return "🛏️"
      case "ropa":
        return "👕"
      case "figuritas":
        return "🎌"
      default:
        return "📦"
    }
  }

  return (
    <div className="bg-white border-2 border-purple-200 rounded-lg overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:scale-105 flex flex-col h-full">
      <div className="relative bg-gradient-to-b from-gray-100 to-gray-200 h-40 md:h-48 flex items-center justify-center overflow-hidden">
        {product.image_url ? (
          <img
            src={product.image_url || "/placeholder.svg"}
            alt={product.name}
            className="w-full h-full object-cover hover:scale-110 transition-transform duration-300"
            onError={(e) => {
              ;(e.target as HTMLImageElement).style.display = "none"
            }}
          />
        ) : (
          <div className="text-4xl md:text-6xl">{getPlaceholderEmoji(product.category)}</div>
        )}
      </div>

      <div className="p-3 md:p-4 flex flex-col flex-1">
        <h3 className="font-bold text-base md:text-lg text-gray-800 mb-1 line-clamp-2">{product.name}</h3>
        <p className="text-gray-600 text-xs md:text-sm mb-2 md:mb-3 line-clamp-2">{product.description}</p>

        <div className="flex justify-between items-center mb-3 md:mb-4 mt-auto">
          <span className="text-xl md:text-2xl font-bold text-pink-600">S/. {Number(product.price).toFixed(2)}</span>
          <span
            className={`text-xs font-semibold px-2 md:px-3 py-1 rounded-full ${
              product.stock > 0 ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"
            }`}
          >
            {product.stock > 0 ? `Stock: ${product.stock}` : "Agotado"}
          </span>
        </div>

        <button
          onClick={() => onAddToCart(product)}
          disabled={product.stock === 0}
          className={`w-full py-2 md:py-2.5 rounded-lg font-semibold transition-all duration-200 text-sm md:text-base ${
            product.stock > 0
              ? "bg-gradient-to-r from-purple-600 to-pink-600 text-white hover:from-purple-700 hover:to-pink-700 active:scale-95"
              : "bg-gray-300 text-gray-500 cursor-not-allowed"
          }`}
        >
          {product.stock > 0 ? "🛒 Agregar al Carrito" : "Agotado"}
        </button>
      </div>
    </div>
  )
}
